Codex ShadowTrace

This package does not open the Codex/Mac sandbox and does not auto-start.
It installs local helper commands for a jailbroken iPhone:

  shadowtrace-start
  shadowtrace-stop
  shadowtrace-status

The trace script records Key/IV length and SHA256, JSON key-path/type
skeleton, keychain clear entrypoints, SQL statements, and observed agrp
values. It does not print raw Key/IV.

Logs are written to:

  /var/mobile/ShadowTrace

Start tracing before pressing Change Device or Wipe App in ShadowHelper.

Commands:

  shadowtrace-status
  shadowtrace-start
  shadowtrace-stop

If frida is not installed on the iPhone, shadowtrace-start exits without
making changes and prints a clear error.
