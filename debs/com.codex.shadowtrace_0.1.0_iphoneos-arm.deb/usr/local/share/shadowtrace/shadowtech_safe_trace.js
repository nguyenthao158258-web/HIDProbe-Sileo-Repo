/*
 * ShadowTech runtime trace helper.
 *
 * Purpose:
 * - Trace decryptData:withKey:iv: without printing raw key/iv.
 * - Trace JSON parsing and svInfo as a key-path/type skeleton only.
 * - Trace keychain wipe SQL and app keychain access-group decisions.
 *
 * Output format:
 * - One JSON object per line, prefixed by Frida's normal console.
 * - Sensitive values are summarized by type/length/hash, not printed raw.
 */

'use strict';

const MAX_SCHEMA_ITEMS = 2500;
const MAX_ARRAY_SAMPLE = 3;
const NS_UTF8 = 4;
const hookedImpls = {};
const stmtSql = {};

function now() {
  return (new Date()).toISOString();
}

function mainModuleName() {
  try {
    return Process.enumerateModules()[0].name;
  } catch (_) {
    return 'unknown';
  }
}

function emit(kind, fields) {
  const obj = fields || {};
  obj.kind = kind;
  obj.ts = now();
  obj.pid = Process.id;
  obj.process = mainModuleName();
  console.log(JSON.stringify(obj));
}

function ptrKey(p) {
  try {
    return p.toString();
  } catch (_) {
    return '0x0';
  }
}

function readUtf8Safe(p, maxLen) {
  try {
    if (!p || p.isNull()) return null;
    return Memory.readUtf8String(p, maxLen || 4096);
  } catch (_) {
    return null;
  }
}

function readUtf16Safe(p, maxLen) {
  try {
    if (!p || p.isNull()) return null;
    return Memory.readUtf16String(p, maxLen || 4096);
  } catch (_) {
    return null;
  }
}

function hexFromByteArray(buf) {
  const u8 = new Uint8Array(buf);
  let out = '';
  for (let i = 0; i < u8.length; i++) {
    const h = u8[i].toString(16);
    out += h.length === 1 ? '0' + h : h;
  }
  return out;
}

function makeSha256() {
  const candidates = [
    Module.findExportByName(null, 'CC_SHA256'),
    Module.findExportByName('/usr/lib/system/libcommonCrypto.dylib', 'CC_SHA256'),
    Module.findExportByName('/usr/lib/libcommonCrypto.dylib', 'CC_SHA256')
  ];
  for (let i = 0; i < candidates.length; i++) {
    if (candidates[i]) {
      return new NativeFunction(candidates[i], 'pointer', ['pointer', 'uint32', 'pointer']);
    }
  }
  return null;
}

const CC_SHA256 = makeSha256();

function sha256Ptr(ptrValue, len) {
  if (!CC_SHA256 || !ptrValue || ptrValue.isNull() || len < 0) return null;
  try {
    const out = Memory.alloc(32);
    CC_SHA256(ptrValue, len >>> 0, out);
    return hexFromByteArray(Memory.readByteArray(out, 32));
  } catch (e) {
    return 'sha256_error:' + e;
  }
}

function toObjC(p) {
  if (!ObjC.available || !p || p.isNull()) return null;
  try {
    return new ObjC.Object(p);
  } catch (_) {
    return null;
  }
}

function isKind(obj, className) {
  try {
    const cls = ObjC.classes[className];
    return !!cls && obj.isKindOfClass_(cls);
  } catch (_) {
    return false;
  }
}

function classNameOf(obj) {
  try {
    return obj.$className || obj.class().toString();
  } catch (_) {
    return 'unknown';
  }
}

function stringSummary(obj) {
  try {
    const len = Number(obj.lengthOfBytesUsingEncoding_(NS_UTF8));
    const cstr = obj.UTF8String();
    return {
      type: 'NSString',
      length: len,
      sha256: sha256Ptr(cstr, len)
    };
  } catch (e) {
    return { type: 'NSString', error: String(e) };
  }
}

function dataSummary(obj) {
  try {
    const len = Number(obj.length());
    return {
      type: 'NSData',
      length: len,
      sha256: sha256Ptr(obj.bytes(), len)
    };
  } catch (e) {
    return { type: 'NSData', error: String(e) };
  }
}

function objSummary(p) {
  const obj = toObjC(p);
  if (!obj) return { type: 'pointer', pointer: ptrKey(p) };
  if (isKind(obj, 'NSData')) return dataSummary(obj);
  if (isKind(obj, 'NSString')) return stringSummary(obj);
  if (isKind(obj, 'NSNumber')) return { type: 'NSNumber', objcType: safeObjCType(obj) };
  if (isKind(obj, 'NSDictionary')) return { type: 'NSDictionary', count: safeCount(obj) };
  if (isKind(obj, 'NSArray')) return { type: 'NSArray', count: safeCount(obj) };
  return { type: classNameOf(obj) };
}

function safeObjCType(obj) {
  try {
    return readUtf8Safe(obj.objCType(), 64);
  } catch (_) {
    return 'unknown';
  }
}

function safeCount(obj) {
  try {
    return Number(obj.count());
  } catch (_) {
    return null;
  }
}

function nsStringToString(obj) {
  try {
    return obj.toString();
  } catch (_) {
    return '<unreadable-key>';
  }
}

function skeletonFromObj(obj, path, depth, out, seen) {
  if (out.length >= MAX_SCHEMA_ITEMS) return;
  if (!obj) {
    out.push({ path: path, type: 'nil' });
    return;
  }

  const cname = classNameOf(obj);
  const objectId = ptrKey(obj.handle);
  if (seen[objectId]) {
    out.push({ path: path, type: cname, note: 'cycle' });
    return;
  }
  seen[objectId] = true;

  try {
    if (isKind(obj, 'NSDictionary')) {
      const count = safeCount(obj);
      out.push({ path: path, type: 'NSDictionary', count: count });
      const keys = obj.allKeys();
      const n = Math.min(Number(keys.count()), MAX_SCHEMA_ITEMS - out.length);
      for (let i = 0; i < n; i++) {
        const keyObj = keys.objectAtIndex_(i);
        const key = nsStringToString(keyObj);
        const childPath = path === '$' ? '$.' + key : path + '.' + key;
        const val = obj.objectForKey_(keyObj);
        skeletonFromObj(val, childPath, depth + 1, out, seen);
        if (out.length >= MAX_SCHEMA_ITEMS) break;
      }
      return;
    }

    if (isKind(obj, 'NSArray')) {
      const count = safeCount(obj);
      out.push({ path: path, type: 'NSArray', count: count });
      const n = Math.min(Number(count || 0), MAX_ARRAY_SAMPLE);
      for (let i = 0; i < n; i++) {
        skeletonFromObj(obj.objectAtIndex_(i), path + '[' + i + ']', depth + 1, out, seen);
        if (out.length >= MAX_SCHEMA_ITEMS) break;
      }
      return;
    }

    if (isKind(obj, 'NSString')) {
      out.push({ path: path, type: 'NSString', length: stringSummary(obj).length });
      return;
    }

    if (isKind(obj, 'NSData')) {
      out.push({ path: path, type: 'NSData', length: dataSummary(obj).length });
      return;
    }

    if (isKind(obj, 'NSNumber')) {
      out.push({ path: path, type: 'NSNumber', objcType: safeObjCType(obj) });
      return;
    }

    if (isKind(obj, 'NSNull')) {
      out.push({ path: path, type: 'NSNull' });
      return;
    }

    out.push({ path: path, type: cname });
  } catch (e) {
    out.push({ path: path, type: cname, error: String(e) });
  } finally {
    delete seen[objectId];
  }
}

function emitSkeleton(label, p) {
  const obj = toObjC(p);
  if (!obj) {
    emit('schema_unavailable', { label: label, summary: objSummary(p) });
    return;
  }
  const out = [];
  skeletonFromObj(obj, '$', 0, out, {});
  emit('json_schema_skeleton', {
    label: label,
    rootType: classNameOf(obj),
    truncated: out.length >= MAX_SCHEMA_ITEMS,
    items: out
  });
}

function extractStrings(obj, maxCount, out) {
  if (!obj || out.length >= maxCount) return;
  try {
    if (isKind(obj, 'NSString')) {
      out.push(obj.toString());
      return;
    }
    if (isKind(obj, 'NSArray')) {
      const n = Math.min(Number(obj.count()), maxCount - out.length);
      for (let i = 0; i < n; i++) extractStrings(obj.objectAtIndex_(i), maxCount, out);
      return;
    }
    if (isKind(obj, 'NSDictionary')) {
      const keys = obj.allKeys();
      const n = Math.min(Number(keys.count()), maxCount - out.length);
      for (let i = 0; i < n; i++) {
        const key = keys.objectAtIndex_(i);
        extractStrings(obj.objectForKey_(key), maxCount, out);
      }
    }
  } catch (_) {
  }
}

function analyzeSql(sql) {
  const lower = sql.toLowerCase();
  const tables = [];
  const tableRe = /\b(?:delete\s+from|insert\s+into|update|select\b.+?\bfrom)\s+([a-z0-9_]+)/ig;
  let m;
  while ((m = tableRe.exec(sql)) !== null) tables.push(m[1]);

  const agrpLiterals = [];
  const litRe = /\bagrp\b[^;\n]*?'([^']*)'/ig;
  while ((m = litRe.exec(sql)) !== null) agrpLiterals.push(m[1]);

  return {
    tables: tables,
    agrpLiterals: agrpLiterals,
    scopeHint: lower.indexOf("agrp not like '%apple%'") !== -1 ? 'broad_non_apple' :
      (lower.indexOf('agrp like') !== -1 || lower.indexOf('agrp in') !== -1 ? 'selective_agrp' : 'unknown'),
    touchesKeychainTables: /\b(genp|inet|cert|keys)\b/i.test(sql),
    isDelete: /\bdelete\s+from\b/i.test(sql)
  };
}

function shouldLogSql(sql) {
  return /\b(delete|insert|update|select)\b/i.test(sql) &&
    (/\b(genp|inet|cert|keys)\b/i.test(sql) || /\bagrp\b/i.test(sql) || /keychain/i.test(sql));
}

function emitSql(source, sql, extra) {
  if (!sql || !shouldLogSql(sql)) return;
  const fields = extra || {};
  fields.source = source;
  fields.sql = sql;
  fields.analysis = analyzeSql(sql);
  emit('sqlite_statement', fields);
}

function hookExport(name, callbacks) {
  const p = Module.findExportByName(null, name);
  if (!p) return false;
  try {
    Interceptor.attach(p, callbacks);
    emit('hook_installed', { target: name, address: ptrKey(p) });
    return true;
  } catch (e) {
    emit('hook_error', { target: name, error: String(e) });
    return false;
  }
}

function hookSQLite() {
  hookExport('sqlite3_exec', {
    onEnter(args) {
      emitSql('sqlite3_exec', readUtf8Safe(args[1], 65536));
    }
  });

  hookExport('sqlite3_prepare_v2', {
    onEnter(args) {
      this.sql = readUtf8Safe(args[1], 65536);
      this.ppStmt = args[3];
    },
    onLeave() {
      if (!this.sql) return;
      try {
        const stmt = Memory.readPointer(this.ppStmt);
        if (stmt && !stmt.isNull()) stmtSql[ptrKey(stmt)] = this.sql;
      } catch (_) {
      }
      emitSql('sqlite3_prepare_v2', this.sql);
    }
  });

  hookExport('sqlite3_prepare16_v2', {
    onEnter(args) {
      this.sql = readUtf16Safe(args[1], 65536);
      this.ppStmt = args[3];
    },
    onLeave() {
      if (!this.sql) return;
      try {
        const stmt = Memory.readPointer(this.ppStmt);
        if (stmt && !stmt.isNull()) stmtSql[ptrKey(stmt)] = this.sql;
      } catch (_) {
      }
      emitSql('sqlite3_prepare16_v2', this.sql);
    }
  });

  hookExport('sqlite3_bind_text', {
    onEnter(args) {
      const stmt = ptrKey(args[0]);
      const sql = stmtSql[stmt];
      if (!sql || !/\bdelete\s+from\b/i.test(sql)) return;
      const val = readUtf8Safe(args[2], 4096);
      emit('sqlite_bind_text_for_delete', {
        statement: sql,
        index: Number(args[1].toInt32()),
        value: val
      });
    }
  });

  hookExport('sqlite3_step', {
    onEnter(args) {
      const stmt = ptrKey(args[0]);
      const sql = stmtSql[stmt];
      if (sql) emitSql('sqlite3_step', sql);
    }
  });

  hookExport('sqlite3_finalize', {
    onEnter(args) {
      delete stmtSql[ptrKey(args[0])];
    }
  });
}

function commandLooksRelevant(cmd) {
  return cmd && /(sqlite3|zkeychain|keychain-2\.db|delete from|clearKeychain|clearAllKeychain)/i.test(cmd);
}

function readArgv(argv) {
  const out = [];
  try {
    if (!argv || argv.isNull()) return out;
    for (let i = 0; i < 64; i++) {
      const p = Memory.readPointer(argv.add(Process.pointerSize * i));
      if (!p || p.isNull()) break;
      out.push(readUtf8Safe(p, 4096));
    }
  } catch (_) {
  }
  return out;
}

function hookProcessLaunch() {
  hookExport('system', {
    onEnter(args) {
      const cmd = readUtf8Safe(args[0], 65536);
      if (commandLooksRelevant(cmd)) emit('process_command', { source: 'system', command: cmd });
    }
  });

  hookExport('popen', {
    onEnter(args) {
      const cmd = readUtf8Safe(args[0], 65536);
      if (commandLooksRelevant(cmd)) emit('process_command', { source: 'popen', command: cmd });
    }
  });

  hookExport('execve', {
    onEnter(args) {
      const path = readUtf8Safe(args[0], 4096);
      const argv = readArgv(args[1]);
      const joined = [path].concat(argv).join(' ');
      if (commandLooksRelevant(joined)) emit('process_command', { source: 'execve', path: path, argv: argv });
    }
  });

  hookExport('posix_spawn', {
    onEnter(args) {
      const path = readUtf8Safe(args[1], 4096);
      const argv = readArgv(args[4]);
      const joined = [path].concat(argv).join(' ');
      if (commandLooksRelevant(joined)) emit('process_command', { source: 'posix_spawn', path: path, argv: argv });
    }
  });

  hookExport('posix_spawnp', {
    onEnter(args) {
      const path = readUtf8Safe(args[1], 4096);
      const argv = readArgv(args[4]);
      const joined = [path].concat(argv).join(' ');
      if (commandLooksRelevant(joined)) emit('process_command', { source: 'posix_spawnp', path: path, argv: argv });
    }
  });
}

function hookObjCMethod(className, methodName) {
  try {
    const cls = ObjC.classes[className];
    if (!cls || !cls[methodName]) return false;
    const impl = cls[methodName].implementation;
    const key = ptrKey(impl);
    if (hookedImpls[key]) return true;
    hookedImpls[key] = true;

    Interceptor.attach(impl, {
      onEnter(args) {
        this.className = className;
        this.methodName = methodName;
        if (methodName.indexOf('decryptData:withKey:iv:') !== -1) {
          emit('decrypt_call', {
            className: className,
            method: methodName,
            data: objSummary(args[2]),
            key: objSummary(args[3]),
            iv: objSummary(args[4])
          });
        } else if (methodName.indexOf('JSONObjectWithData:options:error:') !== -1) {
          this.isJsonParse = true;
          this.input = objSummary(args[2]);
        } else if (methodName.indexOf('setSvInfo:') !== -1) {
          emitSkeleton(className + ' ' + methodName + ' arg0', args[2]);
        } else if (methodName.indexOf('clearKeychainByApp:') !== -1 ||
                   methodName.indexOf('clearKeychain:') !== -1 ||
                   methodName.indexOf('clearAllKeychain') !== -1) {
          emit('keychain_clear_method_enter', {
            className: className,
            method: methodName,
            arg0: objSummary(args[2])
          });
        } else if (methodName.indexOf('runCmd:') !== -1) {
          const cmdObj = toObjC(args[2]);
          const cmd = cmdObj && isKind(cmdObj, 'NSString') ? cmdObj.toString() : null;
          if (commandLooksRelevant(cmd)) emit('process_command', { source: className + ' ' + methodName, command: cmd });
        }
      },
      onLeave(retval) {
        try {
          if (methodName.indexOf('JSONObjectWithData:options:error:') !== -1) {
            emit('json_parse_return', {
              className: className,
              method: methodName,
              input: this.input,
              result: objSummary(retval)
            });
            emitSkeleton(className + ' ' + methodName + ' return', retval);
          } else if (methodName.indexOf('svInfo') !== -1 && methodName.indexOf('setSvInfo:') === -1) {
            emitSkeleton(className + ' ' + methodName + ' return', retval);
          } else if (methodName.indexOf('getAppKeychainKey:') !== -1 ||
                     methodName.indexOf('getAllAppKeychainKey') !== -1 ||
                     methodName.indexOf('getArgpoFapp:') !== -1) {
            const obj = toObjC(retval);
            const strings = [];
            if (obj) extractStrings(obj, 200, strings);
            emit('keychain_agrp_result', {
              className: className,
              method: methodName,
              result: objSummary(retval),
              strings: strings
            });
          }
        } catch (e) {
          emit('objc_leave_error', { className: className, method: methodName, error: String(e) });
        }
      }
    });

    emit('hook_installed', { target: className + ' ' + methodName, address: key });
    return true;
  } catch (e) {
    emit('hook_error', { target: className + ' ' + methodName, error: String(e) });
    return false;
  }
}

function hookMatchingObjCMethods(needles) {
  if (!ObjC.available) {
    emit('objc_unavailable', {});
    return;
  }
  const found = [];
  for (const className in ObjC.classes) {
    let methods = [];
    try {
      methods = ObjC.classes[className].$ownMethods || [];
    } catch (_) {
      continue;
    }
    methods.forEach(function (methodName) {
      for (let i = 0; i < needles.length; i++) {
        if (methodName.indexOf(needles[i]) !== -1) {
          if (hookObjCMethod(className, methodName)) {
            found.push(className + ' ' + methodName);
          }
          break;
        }
      }
    });
  }
  emit('objc_scan_complete', { hooks: found });
}

function install() {
  emit('trace_start', {
    note: 'Safe trace: raw Key/IV and raw decrypted values are not printed.'
  });
  hookSQLite();
  hookProcessLaunch();
  hookMatchingObjCMethods([
    'decryptData:withKey:iv:',
    'JSONObjectWithData:options:error:',
    'svInfo',
    'setSvInfo:',
    'clearKeychainByApp:',
    'clearKeychain:',
    'clearAllKeychain',
    'getAppKeychainKey:',
    'getAllAppKeychainKey',
    'getArgpoFapp:',
    'runCmd:'
  ]);
}

if (ObjC.available) {
  ObjC.schedule(ObjC.mainQueue, install);
} else {
  install();
}
