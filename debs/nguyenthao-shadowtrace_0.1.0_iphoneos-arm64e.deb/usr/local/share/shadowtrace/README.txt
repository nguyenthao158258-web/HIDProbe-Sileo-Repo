Nguyen Thao ShadowTrace

Manual forensic trace helper for ShadowTech research on a jailbroken iPhone.

Installed files:

  /usr/local/bin/ShadowTraceCtl
  /usr/local/share/shadowtrace/README.txt

Commands:

  ShadowTraceCtl status
  ShadowTraceCtl start
  ShadowTraceCtl start ShadowHelper
  ShadowTraceCtl start shadowios
  ShadowTraceCtl stop
  ShadowTraceCtl script

Logs:

  /var/mobile/ShadowTrace

At runtime the binary writes its embedded Frida script to:

  /var/mobile/ShadowTrace/shadowtech_safe_trace.js

The trace script records Key/IV length and SHA256, JSON key-path/type
skeleton, keychain clear entrypoints, SQL statements, and observed agrp
values. It does not print raw Key/IV.

This package does not auto-start and does not install source code into the
public Sileo repository.
